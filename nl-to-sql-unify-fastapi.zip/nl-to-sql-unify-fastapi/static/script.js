// ─── DOM Elements ──────────────────────────────────────────────────────────
const runQueryBtn = document.getElementById('run-query-btn');
const questionInput = document.getElementById('question-input');
const statusContainer = document.getElementById('status-container');
const statusText = document.getElementById('status-text');
const statusSteps = document.getElementById('status-steps');
const resultsSection = document.getElementById('results-section');
const sourceIndicator = document.getElementById('source-indicator');
const rowMetric = document.getElementById('row-metric');
const rowCount = document.getElementById('row-count');
const sqlBlock = document.getElementById('sql-block');
const sqlCode = document.getElementById('sql-code');
const tableContainer = document.getElementById('table-container');
const tableHead = document.getElementById('table-head');
const tableBody = document.getElementById('table-body');
const downloadCsvBtn = document.getElementById('download-csv-btn');
const errorEl = document.getElementById('error-msg');

let lastResultData = null;

// ─── Sidebar: Schema Discovery ────────────────────────────────────────────
async function loadSchema() {
    const tableCountEl = document.getElementById('table-count');
    const tableListEl = document.getElementById('schema-table-list');

    tableListEl.innerHTML = '<span class="muted">Loading...</span>';

    try {
        const resp = await fetch('/schema');
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const data = await resp.json();

        // Count unique tables
        const tables = new Set();
        (data.schema_entries || []).forEach(entry => {
            const key = `${entry.catalog}.${entry.schema || entry.schema_name}.${entry.table}`;
            tables.add(key);
        });

        tableCountEl.textContent = tables.size;

        // Populate table list grouped by schema
        if (tables.size > 0) {
            const grouped = {};
            Array.from(tables).sort().forEach(t => {
                const parts = t.split('.');
                const schemaKey = parts.slice(0, 2).join('.');
                if (!grouped[schemaKey]) grouped[schemaKey] = [];
                grouped[schemaKey].push(parts[2]);
            });

            let html = '';
            for (const [schema, tbls] of Object.entries(grouped)) {
                html += `<div class="schema-group">`;
                html += `<div class="schema-group-header">${escapeHtml(schema)}</div>`;
                html += `<ul class="schema-group-list">`;
                tbls.forEach(tbl => {
                    html += `<li class="schema-table-item">${escapeHtml(tbl)}</li>`;
                });
                html += `</ul></div>`;
            }
            tableListEl.innerHTML = html;
        } else {
            tableListEl.innerHTML = '<span class="muted">No tables found</span>';
        }
    } catch (err) {
        tableListEl.innerHTML = `<span class="muted">Error: ${escapeHtml(err.message)}</span>`;
    }
}

document.getElementById('refresh-schema-btn').addEventListener('click', loadSchema);

// Load schema on page load
loadSchema();

// ─── Sidebar: Health Check on Load ────────────────────────────────────────
async function checkHealth() {
    try {
        const resp = await fetch('/health');
        if (!resp.ok) throw new Error();
        const data = await resp.json();

        const sqlStatus = document.getElementById('sql-status');
        const apiStatus = document.getElementById('api-status');

        if (data.status === 'healthy') {
            sqlStatus.textContent = 'Connected';
            sqlStatus.className = 'config-status success';
        } else {
            sqlStatus.textContent = 'Not configured';
            sqlStatus.className = 'config-status error';
        }

        if (data.api_fallback_configured) {
            apiStatus.textContent = 'Unify API configured';
            apiStatus.className = 'config-status success';
        } else {
            apiStatus.textContent = 'Public APIs active (no key needed)';
            apiStatus.className = 'config-status warning';
        }
    } catch (err) {
        // Silently fail
    }
}

checkHealth();

// ─── Run Query ─────────────────────────────────────────────────────────────
runQueryBtn.addEventListener('click', async () => {
    const question = questionInput.value.trim();
    if (!question) {
        showError('Please enter a question first.');
        return;
    }

    // Reset UI
    hideAll();
    statusContainer.classList.remove('hidden');
    statusText.textContent = 'Processing your question...';
    statusSteps.innerHTML = '<div class="step">Converting natural language to SQL...</div>';
    runQueryBtn.disabled = true;

    try {
        const payload = { question, force_sql: false, force_api: false };

        const resp = await fetch('/query', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });

        if (!resp.ok) {
            const err = await resp.json();
            throw new Error(err.detail || `HTTP ${resp.status}`);
        }

        const data = await resp.json();
        lastResultData = data;

        // Update status
        if (data.source === 'sql_warehouse') {
            statusSteps.innerHTML += '<div class="step">Executing SQL against Unity Catalog...</div>';
        } else {
            statusSteps.innerHTML += '<div class="step">Querying external Public API...</div>';
        }

        statusText.textContent = 'Query complete!';
        document.querySelector('.status-spinner').style.display = 'none';

        // Show results
        renderResult(data);
    } catch (err) {
        statusContainer.classList.add('hidden');
        showError(err.message);
    } finally {
        runQueryBtn.disabled = false;
    }
});

// Also support Enter key in textarea (Shift+Enter for newline)
questionInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        runQueryBtn.click();
    }
});

function renderResult(data) {
    resultsSection.classList.remove('hidden');

    // Source indicator
    if (data.source === 'sql_warehouse') {
        sourceIndicator.className = 'source-indicator sql';
        sourceIndicator.innerHTML = '&#x1F4CA; <strong>Data Source:</strong> Unity Catalog (SQL Warehouse)';
    } else {
        sourceIndicator.className = 'source-indicator api';
        const apiName = data.api_source || 'Public API';
        sourceIndicator.innerHTML = '&#x1F310; <strong>Data Source:</strong> ' + escapeHtml(apiName) + ' (external)';
    }

    // Row count
    rowMetric.classList.remove('hidden');
    rowCount.textContent = data.row_count || 0;

    // SQL block
    if (data.generated_sql) {
        sqlBlock.classList.remove('hidden');
        sqlCode.textContent = data.generated_sql;
    }

    // Response mode badge
    const modeLabel = data.response_mode === 'sync' ? 'Inline' :
                      data.response_mode === 'file' ? 'File Download' : 'Persisted Table';
    const sizeInfo = data.size_bytes ? ` (${formatBytes(data.size_bytes)})` : '';
    sourceIndicator.innerHTML += `<br><small><strong>Response Mode:</strong> ${modeLabel}${sizeInfo}</small>`;

    // ─── Tier 1: Sync (inline data) ───
    if (data.response_mode === 'sync') {
        if (data.columns && data.columns.length > 0 && data.data && data.data.length > 0) {
            tableContainer.classList.remove('hidden');
            tableHead.innerHTML = '<tr>' + data.columns.map(c => `<th>${escapeHtml(c)}</th>`).join('') + '</tr>';
            tableBody.innerHTML = data.data.map(row => {
                if (Array.isArray(row)) {
                    return '<tr>' + row.map(val => `<td>${escapeHtml(String(val ?? ''))}</td>`).join('') + '</tr>';
                } else {
                    return '<tr>' + data.columns.map(c => `<td>${escapeHtml(String(row[c] ?? ''))}</td>`).join('') + '</tr>';
                }
            }).join('');
            downloadCsvBtn.classList.remove('hidden');
        }
    }

    // ─── Tier 2: File download URL ───
    else if (data.response_mode === 'file') {
        const downloadArea = document.createElement('div');
        downloadArea.className = 'download-area';
        downloadArea.innerHTML = `
            <div class="file-download-card">
                <p><strong>Result too large for inline display (${data.row_count.toLocaleString()} rows)</strong></p>
                <p class="muted">Download the CSV file below. Link expires in 10 minutes.</p>
                <a href="${data.download_url}" class="btn-download-link" download>Download CSV</a>
            </div>
        `;
        tableContainer.parentNode.insertBefore(downloadArea, tableContainer);
    }

    // ─── Tier 3: Persisted Delta table ───
    else if (data.response_mode === 'table') {
        const tableArea = document.createElement('div');
        tableArea.className = 'persisted-table-card';
        tableArea.innerHTML = `
            <div class="file-download-card">
                <p><strong>Result persisted to Delta table (${data.row_count.toLocaleString()} rows)</strong></p>
                <p class="muted">The data has been saved to a Databricks table for further querying:</p>
                <code class="table-ref">${escapeHtml(data.table_name)}</code>
                <p class="muted" style="margin-top:8px;">Query it with: <code>SELECT * FROM ${escapeHtml(data.table_name)}</code></p>
            </div>
        `;
        tableContainer.parentNode.insertBefore(tableArea, tableContainer);
    }
}

// ─── Download CSV ──────────────────────────────────────────────────────────
downloadCsvBtn.addEventListener('click', () => {
    if (!lastResultData || !lastResultData.columns || !lastResultData.data) return;

    const cols = lastResultData.columns;
    const rows = lastResultData.data;

    let csv = cols.map(c => `"${c}"`).join(',') + '\n';
    rows.forEach(row => {
        if (Array.isArray(row)) {
            csv += row.map(val => `"${String(val ?? '').replace(/"/g, '""')}"`).join(',') + '\n';
        } else {
            csv += cols.map(c => `"${String(row[c] ?? '').replace(/"/g, '""')}"`).join(',') + '\n';
        }
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'query_results.csv';
    a.click();
    URL.revokeObjectURL(url);
});

// ─── Helpers ───────────────────────────────────────────────────────────────
function hideAll() {
    statusContainer.classList.add('hidden');
    resultsSection.classList.add('hidden');
    errorEl.classList.add('hidden');
    sqlBlock.classList.add('hidden');
    tableContainer.classList.add('hidden');
    rowMetric.classList.add('hidden');
    downloadCsvBtn.classList.add('hidden');
    // Reset spinner
    const spinner = document.querySelector('.status-spinner');
    if (spinner) spinner.style.display = '';
}

function showError(msg) {
    errorEl.textContent = msg;
    errorEl.classList.remove('hidden');
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}